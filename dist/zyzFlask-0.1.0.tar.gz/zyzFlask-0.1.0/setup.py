from setuptools import setup

print("===========================================================")

setup(
    name = 'zyzFlask',
    version = '0.1.0',
    packages = ['configs', 'core'],
    author = 'Asian.zhang',
    author_email = 'Asian_zhang@163.com',
    url='',
    license = "GNU Lesser General",
    description = '基于flask封装的web开发包'
)