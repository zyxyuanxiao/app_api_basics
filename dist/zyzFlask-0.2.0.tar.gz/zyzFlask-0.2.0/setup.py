from setuptools import setup

print("===========================================================")

setup(
    name = 'zyzFlask',
    version = '0.2.0',
    packages = ['configs', 'core'],
    author = 'Asian.zhang',
    author_email = 'Asian_zhang@163.com',
    url='',
    license = "MIT License",
    description = '基于flask封装的web开发包'
)