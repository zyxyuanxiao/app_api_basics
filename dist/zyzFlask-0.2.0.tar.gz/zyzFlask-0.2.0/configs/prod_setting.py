
AES_KEY = 'magicCube-moFang-r'
AUTH_COOKIE_KEY = 'moFangHr-r'


REDIS_HOST = '10.0.3.6'
REDIS_PORT = 6379
REDIS_PASSWORD = 'SDOjx2HcHu'


SQLALCHEMY_DATABASE_URI = 'postgresql://mfmobile:8wmmmO7j2I@weixin.postgresql.mofanghr.service:3433/mofang_mobile'
SQLALCHEMY_POOL_SIZE = 50
SQLALCHEMY_TRACK_MODIFICATIONS = True